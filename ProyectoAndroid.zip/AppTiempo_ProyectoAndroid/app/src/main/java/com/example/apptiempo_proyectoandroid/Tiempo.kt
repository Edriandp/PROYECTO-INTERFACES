package com.example.apptiempo_proyectoandroid

import UserPreferencesSQLiteOpenHelper
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.ComponentCaller
import android.content.Intent
import android.media.Image
import android.media.MediaRecorder
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.lang.ref.ReferenceQueue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Tiempo : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")

    private val RQ_SPEECH_REC = 102
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_tiempo)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val ApiKey = "a21d1ca3eda33b1811470b3451d56f32"
        val inputCity = findViewById<TextInputEditText>(R.id.inputCity)
        val imageView = findViewById<ImageView>(R.id.profileImageView)
        val bundle = intent.extras
        val idUsername = bundle?.getString("username")

        val microphone = findViewById<ImageView>(R.id.microphone)

        val bWeather = findViewById<Button>(R.id.bGetWeather)

        val preferences =
            UserPreferencesSQLiteOpenHelper(this).getPreferences(idUsername.toString())
        val profilePreferences = ProfilePreferences()
        if (preferences != null) {
            if (preferences.nightMode == 1) {
                profilePreferences.toggleNightMode(true)
            } else {
                profilePreferences.toggleNightMode(false)
            }
            if (preferences.loadCity == 1) {
                val city = preferences.city
                getWeatherData(city, ApiKey)
            }
        }
        bWeather.setOnLongClickListener { view ->
            // Lista de Strings que queremos mostrar
            val items = listOf("Madrid", "Londres", "Barcelona", "Nueva York")

            // Crear el AlertDialog para mostrar la lista
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Seleccione una opción")
                .setItems(items.toTypedArray()) { dialog, which ->
                    // Manejo de la opción seleccionada
                    val selectedOption = items[which]
                    val inputCity = findViewById<TextInputEditText>(R.id.inputCity)
                    inputCity.setText(selectedOption)
                    bWeather.performClick()
                }
                .setCancelable(true)

            // Mostrar el dialogo
            builder.show()
            true  // Retorna true para indicar que el evento fue consumido
        }
        //evento de click en el botón de obtener el clima
        bWeather.setOnClickListener {
            val city = inputCity.text.toString()
            getWeatherData(city, ApiKey)
        }
        //Evento de click en la imagen de perfil
        imageView.setOnClickListener {
            val intent = Intent(this, ProfilePreferences::class.java)
            intent.putExtra("username", idUsername)
            startActivity(intent)
        }
        //Evento de reconocimiento de voz
        microphone.setOnClickListener {
            beginRecording()
        }


    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?,
    ) {
        super.onActivityResult(requestCode, resultCode, data)
        //control de errores en caso de que no se pueda usar el reconocimiento de voz
        if (requestCode == RQ_SPEECH_REC && resultCode == Activity.RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val inputCity = findViewById<TextInputEditText>(R.id.inputCity)
            if (result != null) {
                if (result.get(0).contains("salir")) {
                    finish() //Cerrar la actividad

                } else
                    if (result.get(0).contains("preferencia")) {
                        val intent = Intent(this, ProfilePreferences::class.java)
                        startActivity(intent) //Iniciar la actividad de preferencias
                    } else
                        if (result.get(0).contains("limpiar")) {
                            inputCity.setText("") //Limpiar el campo de texto

                        } else {
                            inputCity.setText(result?.get(0))
                                .toString() //Escribir la ciudad en el campo de texto
                        }
            }

        }
    }

    fun beginRecording() {
        //control de errores en caso de que no se pueda usar el reconocimiento de voz
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Reconocimiento de voz no disponible", Toast.LENGTH_SHORT)
                .show()
            return
        } else {
            //iniciar el intento de la actividad de reconocimiento de voz
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(
                //Configuración del reconocimiento de voz
                RecognizerIntent.EXTRA_LANGUAGE_MODEL, //Modelo de lenguaje
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM //Modelo de lenguaje libre
            )
            i.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE,
                Locale.getDefault()
            ) //Detectar idioma dependiendo del dispositivo
            i.putExtra(
                RecognizerIntent.EXTRA_PROMPT,
                "Acciones: 'salir', 'preferencias', 'limpiar', 'Decir una ciudad'" //Mensaje de ayuda de acciones
            )
            startActivityForResult(i, RQ_SPEECH_REC) //Iniciar el reconocimiento de voz
        }
    }

    fun getWeatherData(city: String, apiKey: String) {
        // Referencias a los elementos de la interfaz
        val tvLocation = findViewById<TextView>(R.id.location)
        val imageView = findViewById<ImageView>(R.id.imageView)
        val tvWeather = findViewById<TextView>(R.id.tvWeather)
        val tvTemp = findViewById<TextView>(R.id.tvTemp)
        val tvRain = findViewById<TextView>(R.id.tvRain)
        val tvHumidity = findViewById<TextView>(R.id.tvHumidity)
        val tvWindSpeed = findViewById<TextView>(R.id.tvWindSpeed)

        // Crear cliente HTTP
        val client = OkHttpClient()

        // URL de la API
        val url =
            "https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric"

        // Crear la solicitud
        val request = Request.Builder()
            .url(url)
            .build()

        // Ejecutar la llamada en un hilo separado
        Thread {
            try {
                // Ejecutar la solicitud
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        // Acceder al cuerpo de la respuesta
                        val responseBody = response.body?.string()
                        Log.d("WeatherAPI", "Response: $responseBody")


                        if (responseBody != null) {
                            // Parsear el JSON
                            val json = JSONObject(responseBody)

                            // Extraer datos del JSON
                            val cityName = json.getString("name")
                            val temp = json.getJSONObject("main").getDouble("temp")
                            val weatherDescription = json.getJSONArray("weather")
                                .getJSONObject(0).getString("description")
                            val humidity = json.getJSONObject("main").getInt("humidity")
                            val windSpeed = json.getJSONObject("wind").getDouble("speed")
                            val rainProbability =
                                json.optJSONObject("rain")?.optDouble("1h") ?: 0.0
                            val timestamp = json.getLong("dt") * 1000

                            // Formatear la fecha
                            val date =
                                SimpleDateFormat(
                                    "yyyy-MM-dd HH:mm:ss",
                                    Locale.getDefault()
                                ).format(
                                    timestamp
                                )

                            // Actualizar la UI en el hilo principal
                            runOnUiThread {
                                tvWeather.text = weatherDescription
                                getWeatherIcon(weatherDescription, imageView)
                                tvLocation.text = "$date, $cityName"
                                tvTemp.text = "$temp°C"
                                tvRain.text = "${rainProbability}mm"
                                tvHumidity.text = "$humidity %"
                                tvWindSpeed.text = "$windSpeed m/s"

                            }
                        }
                    } else {
                        Toast.makeText(this, "Ciudad no encontrada", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }

    fun getWeatherIcon(description: String, imageView: ImageView) {
        when {
            description.contains(
                "clear",
                ignoreCase = true
            ) -> imageView.setImageResource(R.drawable.sunny)

            description.contains(
                "cloud",
                ignoreCase = true
            ) -> imageView.setImageResource(R.drawable.cloud)

            description.contains(
                "rain",
                ignoreCase = true
            ) -> imageView.setImageResource(R.drawable.rainy)

            description.contains(
                "thunderstorm",
                ignoreCase = true
            ) -> imageView.setImageResource(R.drawable.storm)

            description.contains(
                "snow",
                ignoreCase = true
            ) -> imageView.setImageResource(R.drawable.snowy)

            description.contains("mist", ignoreCase = true) || description.contains(
                "fog",
                ignoreCase = true
            ) -> imageView.setImageResource(R.drawable.windy)

            description.contains(
                "drizzle",
                ignoreCase = true
            ) -> imageView.setImageResource(R.drawable.rainy)

            else -> imageView.setImageResource(R.drawable.unkown)
        }
    }
}