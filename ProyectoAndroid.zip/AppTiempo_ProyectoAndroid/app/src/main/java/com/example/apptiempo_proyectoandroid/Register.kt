package com.example.apptiempo_proyectoandroid

import AdminSQLiteOpenHelper
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class Register : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val email = findViewById<TextInputEditText>(R.id.inputEmail)
        val password = findViewById<TextInputEditText>(R.id.inputPassword)
        val passrword2 = findViewById<TextInputEditText>(R.id.inputPassword2)
        val username = findViewById<TextInputEditText>(R.id.inputUser)
        val register = findViewById<MaterialButton>(R.id.bResgister)


        register.setOnClickListener {
            val emailText = email.text.toString()
            val passwordText = password.text.toString()
            val password2Text = passrword2.text.toString()
            val usernameText = username.text.toString()
            if(emailText.isEmpty() || passwordText.isEmpty() || password2Text.isEmpty() || usernameText.isEmpty()){
                Toast.makeText(this, "Rellene todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if(!emailText.contains("@")){
                Toast.makeText(this, "Email no válido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if(passwordText.length < 6){
                Toast.makeText(this, "La contraseña debe tener al menos 6 caracteres", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if(!passwordText.contains(Regex("[0-9]"))){
                Toast.makeText(this, "La contraseña debe tener al menos un número", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!passwordText.contains(Regex("[A-Z]"))) {
                Toast.makeText(this, "La contraseña debe tener al menos una mayúscula", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (passwordText == password2Text) {
                val admin = AdminSQLiteOpenHelper(this)
                if (admin.getUser(usernameText)) {
                    Toast.makeText(this, "El usuario ya existe", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                } else {
                    admin.insertUser(usernameText, emailText, passwordText)
                    Intent(this, LoginActivity::class.java).also {
                        startActivity(it)
                    }
                }
            } else {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
            }
        }

    }

}