package com.example.apptiempo_proyectoandroid

import UserPreferencesSQLiteOpenHelper
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.chip.Chip
import com.google.android.material.textfield.TextInputEditText
import java.util.Locale

class ProfilePreferences : AppCompatActivity() {
    val RQ_SPEECH_REC = 102
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_profile_preferences)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        val name = findViewById<TextInputEditText>(R.id.inputName)
        val birthDate = findViewById<TextInputEditText>(R.id.inputDate)
        val city = findViewById<TextInputEditText>(R.id.inputCity)
        val cbCity = findViewById<CheckBox>(R.id.cbCity)
        val nightModeChip = findViewById<Chip>(R.id.chipNightMode)
        Log.d("ProfilePreferences", "Night mode chip: $nightModeChip")



        val bLogout = findViewById<Button>(R.id.bLogout)
        val bSave = findViewById<Button>(R.id.bSave)
        val bundle = intent.extras
        val idUsername = bundle?.getString("username")
        Log.d("ProfilePreferences", "Username recibido: $idUsername")

        val preferences =
            UserPreferencesSQLiteOpenHelper(this).getPreferences(idUsername.toString())

        if (preferences != null) {
            name.setText(preferences.name)
            birthDate.setText(preferences.birthdate)
            city.setText(preferences.city)
            val cityChecked = preferences.loadCity
            if (cityChecked == 1) {
                cbCity.isChecked = true
            } else {
                cbCity.isChecked = false
            }
        }

        nightModeChip.setOnCheckedChangeListener { _, isChecked ->
            try {
                toggleNightMode(isChecked)
                val admin = UserPreferencesSQLiteOpenHelper(this)
                val existingUser = admin.getPreferences(idUsername.toString())
                if (existingUser != null) {
                    admin.updatePreferences(
                        idUsername.toString(),
                        existingUser.name,
                        existingUser.birthdate,
                        existingUser.city,
                        existingUser.loadCity,
                        if (isChecked) 1 else 0 // Guarda el nuevo valor de modo oscuro
                    )
                }
            } catch (e: Exception) {
                Log.e("ProfilePreferences", "Error al cambiar el modo oscuro: ${e.message}")
            }
        }





        bSave.setOnClickListener {
            val admin = UserPreferencesSQLiteOpenHelper(this)
            val existingUser = admin.getPreferences(idUsername.toString())
            if (existingUser == null) {
                admin.insertPreferences(
                    idUsername.toString(),
                    name.text.toString(),
                    birthDate.text.toString(),
                    city.text.toString(),
                    if (cbCity.isChecked) 1 else 0,
                    if (nightModeChip.isChecked) 1 else 0
                )
            } else {
                admin.updatePreferences(
                    idUsername.toString(),
                    name.text.toString(),
                    birthDate.text.toString(),
                    city.text.toString(),
                    if (cbCity.isChecked) 1 else 0,
                    if (nightModeChip.isChecked) 1 else 0
                )
            }
            Intent(this, Tiempo::class.java).also {
                it.putExtra("username", idUsername)
                startActivity(it)
            }
        }
        bLogout.setOnClickListener {
            Intent(this, LoginActivity::class.java).also {
                startActivity(it)
            }
        }

        val microphoneBtn = findViewById<ImageView>(R.id.microphone)
        microphoneBtn.setOnClickListener {
            beginRecording()
        }
    }


    fun toggleNightMode(isDarkMode: Boolean) {
        Log.d("ProfilePreferences", "Cambiar a modo oscuro: $isDarkMode")
        try{
        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }}catch (e: Exception){
            Log.e("ProfilePreferences", "Error al cambiar el modo oscuro: ${e.message}")
        }
    }
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?,
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == RQ_SPEECH_REC && resultCode == Activity.RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (result != null) {
                if (result.get(0).contains("salir")) {
                    finish()
                }
                if (result.get(0).contains("guardar")) {
                    val bSave = findViewById<Button>(R.id.bSave)
                    bSave.performClick()
                }
            }

        }
    }

    fun beginRecording() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Reconocimiento de voz no disponible", Toast.LENGTH_SHORT)
                .show()
            return
        } else {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Acciones: 'salir', 'guardar'")
            startActivityForResult(i, RQ_SPEECH_REC)
        }
    }


}