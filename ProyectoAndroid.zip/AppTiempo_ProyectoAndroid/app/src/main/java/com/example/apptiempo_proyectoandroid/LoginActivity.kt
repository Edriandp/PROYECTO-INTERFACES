package com.example.apptiempo_proyectoandroid

import AdminSQLiteOpenHelper
import UserPreferencesSQLiteOpenHelper
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import java.util.Locale

class LoginActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    val RQ_SPEECH_REC = 102
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.login)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        val bLogin = findViewById<Button>(R.id.bLogin)
        val register = findViewById<TextView>(R.id.register)
        val user = findViewById<TextInputEditText>(R.id.inputUser)
        val password = findViewById<TextInputEditText>(R.id.inputPassword)

        val micropohone = findViewById<ImageView>(R.id.microphone)
        micropohone.setOnClickListener() {
            beginRecording()
        }

        bLogin.setOnClickListener() {
            val db = AdminSQLiteOpenHelper(this).readableDatabase
            val cursor = db.query(
                AdminSQLiteOpenHelper.TABLE_NAME,
                null,
                "${AdminSQLiteOpenHelper.COLUMN_USERNAME} = ? AND ${AdminSQLiteOpenHelper.COLUMN_PASSWORD} = ?",
                arrayOf(user.text.toString(), password.text.toString()),
                null, null, null
            )

            if (cursor.count > 0) {
                val intent = Intent(this, Tiempo::class.java)
                intent.putExtra("username", user.text.toString())
                startActivity(intent)
            } else {
                Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
            }
        }
        register.setOnClickListener() {
            val intent = Intent(this, Register::class.java)
            startActivity(intent)
        }

    }

    fun toggleNightMode(isDarkMode: Boolean) {
        Log.d("ProfilePreferences", "Cambiar a modo oscuro: $isDarkMode")
        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?,
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == RQ_SPEECH_REC && resultCode == Activity.RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val inputname = findViewById<TextInputEditText>(R.id.inputUser)
            val inputpassword = findViewById<TextInputEditText>(R.id.inputPassword)
            if (result != null) {
                if (result.get(0).contains("nombre")) {
                    inputname.setText(result.get(0).substring(7))
                } else
                    if (result.get(0).contains("contraseña")) {
                        inputpassword.setText(result.get(0).substring(12))

                    } else if (result.get(0).contains("registrarse")) {
                        val intent = Intent(this, Register::class.java)
                        startActivity(intent)

                    } else {
                        if (result.get(0).contains("login")) {
                            val db = AdminSQLiteOpenHelper(this).readableDatabase
                            val cursor = db.query(
                                AdminSQLiteOpenHelper.TABLE_NAME,
                                null,
                                "${AdminSQLiteOpenHelper.COLUMN_USERNAME} = ? AND ${AdminSQLiteOpenHelper.COLUMN_PASSWORD} = ?",
                                arrayOf(inputname.text.toString(), inputpassword.text.toString()),
                                null, null, null
                            )

                            if (cursor.count > 0) {
                                val intent = Intent(this, Tiempo::class.java)
                                intent.putExtra("username", inputname.text.toString())
                                startActivity(intent)
                            } else {
                                Toast.makeText(
                                    this,
                                    "Usuario o contraseña incorrectos",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }


            }
        }


    }
    fun beginRecording() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Reconocimiento de voz no disponible", Toast.LENGTH_SHORT)
                .show()
            return
        } else {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Acciones: 'nombre', 'contraseña', 'registrarse', 'login'")
            startActivityForResult(i, RQ_SPEECH_REC)
        }
    }
}

